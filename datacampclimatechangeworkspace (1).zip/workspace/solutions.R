# Instruction Solutions

# ================ SOLUTION 1 =============================

# rename columns
ipcc_2006_africa <- ipcc_2006_africa %>%
  rename(
    Region=C_group_IM24_sh, 
    Code=Country_code_A3,
    Industry=ipcc_code_2006_for_standard_report_name
  )


totals_by_country_africa <- totals_by_country_africa %>% 
  rename(
    Region=C_group_IM24_sh, 
    Code=Country_code_A3
  )


# drop columns
ipcc_2006_africa <- ipcc_2006_africa %>% 
  select(-c('IPCC_annex', 'ipcc_code_2006_for_standard_report', 'Substance'))

totals_by_country_africa <- totals_by_country_africa %>% 
  select(-c('IPCC_annex', 'Substance'))


# Melt and clean Year column
melt_clean <- function(df){
  long <- df %>% pivot_longer(
    Y_1970:Y_2021, 
    names_to = 'Year', values_to = 'CO2', 
    # remove the 'Y_' prefix
    names_prefix = 'Y_', 
    # convert year to integer
    names_transform = list(Year = as.integer)
  ) %>% 
    filter(!is.na(CO2))
  
  return(long)
}


ipcc_2006_africa <- melt_clean(ipcc_2006_africa)
totals_by_country_africa <- melt_clean(totals_by_country_africa)



# ================ SOLUTION 2 =============================

#Summarize the 'ipcc_2006_africa' df and save the result by year and region as co2_level_by_region
co2_level_by_region_per_year <- totals_by_country_africa %>%
  group_by(Region, Year)%>%
  summarize(co2_level = mean(CO2))


# visualizing the trend
trend_of_CO2_emission_plot <- ggplot(co2_level_by_region_per_year, aes(x = Year, y = co2_level, color = Region)) +
  # geom_point() +
  geom_line() +
  ggtitle("CO2 levels across the African Regions between 1970 and 2021")


# ======================== SOLUTION 3 ============================== 

relationship_btw_time_CO2 <- totals_by_country_africa %>% 
  group_by(Region) %>%
  summarise(r = cor(Year, CO2, method = 'spearman'))


# ======================= SOLUTION 4 ============================== 


# ANOVA
aov_results <- aov(CO2 ~ Region, data = totals_by_country_africa)

# probe further to reveal the location of significant difference
pw_ttest_result <- pairwise.t.test(
  totals_by_country_africa$CO2, 
  totals_by_country_africa$Region, 
  p.adjust.method = "bonferroni"
)


# ======================= SOLUTION 5 ==============================

# Top 5 industries by count
top_5_industries <- ipcc_2006_africa %>%
  group_by(Region) %>%
  count(Industry) %>%
  slice_max(n = 5, order_by = n)


# ========================= SOLUTION 6 =============================

top_industry_by_co2_emission <- ipcc_2006_africa %>%
  group_by(Region, Industry)%>%
  summarize(co2_level = mean(CO2))%>%
  slice_max(n = 1, order_by = co2_level)


# =========================== SOLUTION 7 =============================

model <- lm(log10(CO2) ~ Year + Region, data = totals_by_country_africa)

# create a dataframe for the predicted value
newdata <- data.frame(Year = 2025, Region = african_regions)

# predict the CO2 for year 2025
predicted_co2 <- predict(model, newdata = newdata)

predicted_co2 <- 10^predicted_co2


# ============================ SOLUTION 8 ======================


selected_countries <- totals_by_country_africa %>%
  select(Name, Year, CO2) %>%
  filter(Name %in% c("Ethiopia", "Mozambique", "Nigeria", "Tunisia"))

temp_long <- temperatures %>% 
  pivot_longer(
    Ethiopia:Tunisia, 
    names_to = 'Name', 
    values_to = 'Temperature'
  )

joined <- selected_countries %>% inner_join(temp_long)


# joined %>% 
#   ggplot(aes(log10(CO2), Temperature, color = Name)) +
#   geom_point() +
#   labs(
#     title = "Relationship between Temperature and CO2",
#     y = "Temperature (C)",
#     x = "CO2 (kt) in log base 10"
#   )

model_temp <- lm(Temperature ~ log10(CO2) + Name, data = joined)
