
solution_1_tests <- function() {
  # Helper functions
  isIn <- function(needle, haystack) {
    return(needle %in% haystack)
  }
  
  isNotIn <- function(needle, haystack) {
    !isIn(needle, haystack)
  }
  
  
  # THE CHECK FUNCTIONS
  
  #' The function checks if the dataset columns were renamed
  #' according to the instructions
  columns_were_renamed <- function(ipcc_2006_africa, totals_by_country_africa) {
    
    d1 <- 'ipcc_2006_africa'
    d2 <- 'totals_by_country_africa'
    
    renameMsg <- function(old, new, dataset_name) {
      sprintf('Have you renamed %s column to %s in the %s dataset?\n',old, new, dataset_name)
    }
    
    # Arrange
    ipcc_cols = names(ipcc_2006_africa) %>% tolower() %>% sort()
    totals_cols = names(totals_by_country_africa) %>% tolower() %>% sort()
    
    
    # Check if the columns have been renamed
    assert_that(
      isNotIn('c_group_im24_sh', ipcc_cols) && isIn('region', ipcc_cols), 
      msg = renameMsg('C_group_IM24_sh', 'Region', d1)
    )
    
    assert_that(
      isNotIn('country_code_a3', ipcc_cols) && isIn('code', ipcc_cols), 
      msg = renameMsg('Country_code_A3', 'Code', d1)
    )
    
    assert_that(
      isNotIn('ipcc_code_2006_for_standard_report_name', ipcc_cols) && isIn('industry', ipcc_cols), 
      msg = renameMsg('ipcc_code_2006_for_standard_report_name', 'Industry', d1)
    )
    
    
    assert_that(
      isNotIn('c_group_im24_sh', totals_cols) && isIn('region', totals_cols), 
      msg = renameMsg('C_group_IM24_sh', 'Region', d2)
    )
    
    assert_that(
      isNotIn('country_code_a3', totals_cols) && isIn('code', totals_cols), 
      msg = renameMsg('Country_code_A3', 'Code', d2)
    )
    
  }
  
  #' The function checks if columns IPCC_annex, ipcc_code_2006_for_standard_report, and Substance were dropped
  columns_were_dropped <- function(ipcc_2006_africa, totals_by_country_africa) {
    
    # Arrange
    ipcc_cols = names(ipcc_2006_africa) %>% tolower() %>% sort()
    totals_cols = names(totals_by_country_africa) %>% tolower() %>% sort()
    
    d1 <- 'ipcc_2006_africa'
    d2 <- 'totals_by_country_africa'
    
    dropMsg <- function(col, dataset_name) {
      sprintf('Did you drop %s column from %s dataset? Please check your code!\n', col, dataset_name)
    }
    
    assert_that(isNotIn('ipcc_annex', ipcc_cols), msg = dropMsg('IPCC_annex', d1))
    
    assert_that(isNotIn('ipcc_code_2006_for_standard_report', ipcc_cols), msg = dropMsg('ipcc_code_2006_for_standard_report', d1))
    
    assert_that(isNotIn('substance', ipcc_cols), msg = dropMsg('Substance', d1))
    
    assert_that(isNotIn('ipcc_annex', totals_cols), msg = dropMsg('IPCC_annex', d2))
    
    assert_that(isNotIn('substance', totals_cols), msg = dropMsg('Substance', d2))
    
    
  }
  
  
  column_years_was_gathered <- function(ipcc_2006_africa, totals_by_country_africa) {
    
    ipcc_cols = names(ipcc_2006_africa) %>% tolower() %>% sort()
    totals_cols = names(totals_by_country_africa) %>% tolower() %>% sort()
    
    # Check if the number of columns match the expected number
    assert_that(
      length(ipcc_cols) == 7, 
      msg = "Have you used converted the ipcc_2006_africa dataset from wide to long format?"
    )
    
    assert_that(
      length(totals_cols) == 5, 
      msg = "Have you converted the totals_by_country_africa dataset from wide to long format?"
    )
    
    # Check if the year columns have been gathered into Year and CO2
    assert_that(
      are_equal(ipcc_cols, c('co2', 'code', 'fossil_bio', 'industry', 'name', 'region', 'year')), 
      msg = "Have you gathered the ipcc_2006_africa year columns into Year and CO2?"
    )
    
    assert_that(
      are_equal(totals_cols, c('co2', 'code', 'name', 'region', 'year')),
      msg="Have you gathered the totals_by_country_africa year columns into Year and CO2?"
    )
  }
  
  
  co2_col_has_no_nas <- function(ipcc_2006_africa, totals_by_country_africa) {
    
    # Check that rows with missing CO2 have been dropped
    assert_that(
      noNA(ipcc_2006_africa$CO2), 
      msg='Did you drop the rows with missing CO2 in the ipcc_2006_africa dataset?'
    )
    
    assert_that(
      noNA(totals_by_country_africa$CO2), 
      msg='Did you drop the rows with missing CO2 in the totals_by_country_africa dataset?')
    
  }
  
  year_col_has_int_type <- function(ipcc_2006_africa, totals_by_country_africa) {
    # Check that Year column is an integer
    assert_that(
      is.integer(ipcc_2006_africa$Year), 
      msg = "Have you converted the ipcc_2006_africa's Year column to an integer?")
    
    assert_that(
      is.integer(totals_by_country_africa$Year), 
      msg = "Have you converted the totals_by_country_africa's Year column to an integer?")
    
  }
  
  
  check_task_1 <- function(ipcc_2006_africa, totals_by_country_africa) {
    columns_were_renamed(ipcc_2006_africa, totals_by_country_africa)
    columns_were_dropped(ipcc_2006_africa, totals_by_country_africa)
    column_years_was_gathered(ipcc_2006_africa, totals_by_country_africa)
    co2_col_has_no_nas(ipcc_2006_africa, totals_by_country_africa)
    year_col_has_int_type(ipcc_2006_africa, totals_by_country_africa)
  }
  
  return(check_task_1)
  
}



solution_2_8_tests <- function() {
  
  #! Checks if a list contains a result
  test_list_contains_operation_result <- function(my_list, operation_result) {
    # Check if the list exists and is not empty
    assert_that(!is.null(my_list) && length(my_list) > 0, msg = "The list is empty or doesn't exist.")
    
    # Check if the result is present in the list
    assert_that(!is.null(operation_result), msg = "The result of the operation is missing from the list.")
    
    # If all checks pass, return the operation result
    return (TRUE)
  }
  
  
  #! Checks if a dataframe contains an expected result
  assert_dataframe_contains_operation_result <- function(df, operation_result){
    # Check if the dataframe exists and is not empty
    assert_that(!is.null(df) && nrow(df) > 0 && ncol(df) > 0, msg = "The dataframe is empty or doesn't exist.")
    
    # Check if the result is present in the dataframe
    assert_that(all(operation_result %in% df), msg = "The result of the operation is not present in the dataframe.")
    
  }
  
  
  #' Checks if a dataframe dimensions matches the expected values
  assert_dataframe_dimensions <- function(df, rows, cols) {
    # Check if the data frame exists
    assert_that(!is.null(df), msg = "The data frame does not exist.")
    
    # Check if the data frame has the expected number of rows and columns
    assert_that(nrow(df) == rows, msg = paste("The data frame should have", expected_rows, "rows."))
    assert_that(ncol(df) == cols, msg = paste("The data frame should have", expected_cols, "columns."))
  }
  
  
  #' Checks if a created plot match an expected aesthetics
  assert_plot_data_aesthetics <- function(plot_object, expected_data, expected_aesthetics) {
    # Check if the plot object exists
    assert_that(!is.null(plot_object), msg = "The plot object does not exist.")
    
    # Check if the plot object is of class gg/ggplot
    assert_that(inherits(plot_object, c("gg", "ggplot")), msg = "Expected a ggplot2 plot.")
    
    
    # Check if the data used in the plot matches the expected data
    assert_that(all(names(plot_object$data) == names(expected_data)), 
                msg = "The plot data does not match the expected data columns.")
    
    # Check if the aesthetics used in the plot match the expected aesthetics
    assert_that(all(names(plot_object$mapping) == names(expected_aesthetics)), 
                msg = paste("The plot aesthetics do not match the expected aesthetics. Did you use", expected_aesthetics, "as colour aesthetics"))
    
  }
  
  
  
  check_task_2 <- function(co2_level_by_region_per_year, trend_of_CO2_emission_plot) {
    
    assert_dataframe_dimensions(co2_level_by_region_per_year, 208, 3)
    
    assert_plot_data_aesthetics(
      trend_of_CO2_emission_plot,
      
      c(co2_level_by_region_per_year$Year, co2_level_by_region_per_year$co2_level, co2_level_by_region_per_year$Region),
      
      c(co2_level_by_region_per_year$Year, co2_level_by_region_per_year$co2_level, co2_level_by_region_per_year$Region)
    )
  }
  
  
  check_task_3 <- function(relationship_btw_time_CO2) {
    assert_dataframe_dimensions(relationship_btw_time_CO2, 4, 2)
    
    r <- relationship_btw_time_CO2$r %>% round(3)
    
    assert_that(
      are_equal(r, c(0.182, 0.430, 0.261, 0.324)),
      msg = "The Spearman coefficient rs in the East, North, South, and Western Africa should be 0.182, 0.430, 0.261, and 0.324, respectively!"
    )
    
  }
  
  
  check_task_4 <- function(aov_results, pw_ttest_result) {
    
    # Convert to a tidy dataframe
    pw_ttest_result_df <- tidy(pw_ttest_result) %>% 
      mutate(p.value = round(p.value, 3))
    
    row <- pw_ttest_result_df[pw_ttest_result_df$p.value == 1, 1:3] %>% 
      t() %>% 
      as.vector()
    
    assert_dataframe_dimensions(aov_results$model, 2912, 2)
    
    assert_dataframe_dimensions(pw_ttest_result_df, 6, 3)
    
    t1 <- "Southern_Africa" %in% row[1:2]
    t2 <- "Northern_Africa" %in% row[1:2]
    t3 <- "Western_Africa" %in% row[4:5]
    t4 <- "Eastern_Africa" %in% row[4:5]
    
    assert_that(t1 && t2 && t3 && t4,
                msg = "Have you conducted a pairwise.t.test correctly?"
    )
    
  }
  
  
  check_task_5 <- function(top_5_industries) {
    
    assert_dataframe_dimensions(top_5_industries, 24, 3)
    
    # select top 2 for testing
    top_2_industries <- top_5_industries %>% 
      slice_max(order_by = n, n = 2)
    
    ind <- tolower(c("Residential and other sectors",
                     "Manufacturing Industries and Construction"))
    
    assert_that(
      are_equal(ind, tolower(top_2_industries$Industry) %>% unique()),
      msg = "Have you correctly determined the top five industries in each African region? Please, check your code!"
    )
    
    assert_that(
      are_equal(top_2_industries$n, c(1454, 1383, 572, 456, 1144, 1067, 2541, 2265)),
      msg = "The count of the top industries doesn't seem to be correct. Please, check your code!"
    )
    
  }
  
  
  check_task_6 <- function(top_industry_by_co2_emission) {
    
    assert_dataframe_dimensions(top_industry_by_co2_emission, 4, 3)
    
    df <- top_industry_by_co2_emission
    
    top_ind <- c("Residential and other sectors",
                 "Main Activity Electricity and Heat Production",
                 "Main Activity Electricity and Heat Production",
                 "Residential and other sectors")
    
    assert_that(
      are_equal(tolower(top_ind), tolower(df$Industry)),
      msg = sprintf("Ouch! the top industry ought to be %s for %s respectively", paste(top_ind, collapse = ", "), paste(df$Region, collapse = ", "))
    )
    
  }
  
  
  check_task_7 <- function(model, predicted_co2, african_regions) {
    assert_that(class(model) == "lm", msg = "Have you called the lm function?")
    
    vals <- c(15177.72, 10788.07, 37761.69, 41081.90)
    
    assert_that(
      all(round(predicted_co2) == round(vals)),
      msg = sprintf("The expected values for %s are %s respectively! Did you convert from log10 to decimals?", paste(african_regions, collapse = ", "), paste(vals, collapse = ", "))
    )
    
  }
  
  
  check_task_8 <- function(model_temp) {
    
    s <- summary(model_temp)
    
    assert_that(
      round(s$adj.r.squared, 2) == 0.98,
      msg = sprintf("Expected an adj.r.squared of 0.98 but got %d. Please, check your model", round(adj.r.squared, 2))
    )
    
    co2_est <- tidy(model_temp)[2, "estimate", drop = T]
    
    assert_that(
      round(co2_est, 2) == 1.95, 
      msg = "The coefficient of log10(CO2) is not 1.95. Please, check your code!")
    
  }
  
  
  return(
    list(
      check_task_2 = check_task_2,
      check_task_3 = check_task_3,
      check_task_4 = check_task_4,
      check_task_5 = check_task_5,
      check_task_6 = check_task_6,
      check_task_7 = check_task_7,
      check_task_8 = check_task_8
    )
  )
  
}

# Create the test runner
runner <- solution_2_8_tests()
runner$check_task_1 = solution_1_tests()

